#include <iostream>

using namespace std;

void isPerfect(int poljubnoSt) {
    int sum = 0;

    for (int i = 1; i <= poljubnoSt / 2; i++) {

        if (poljubnoSt % i == 0) {
            sum = sum + i;
        }
    }

    if (sum == poljubnoSt) {
        cout << "Stevilo je popolno.";
    } else {
        cout << "Stevilo ni popolno.";
    }
}

int sumOfAllNumbers(int poljubnoSt) {
    int sum = 0;
    while (poljubnoSt > 0) {
        int zadnjoSt = poljubnoSt % 10;
        sum = sum + zadnjoSt;
        poljubnoSt = poljubnoSt / 10;
    }
    return sum;
}


int main() {
    int poljubnoSt;
    do {
        cout << "Vnesi poljubno število: \t" << endl;
        cin >> poljubnoSt;
    } while (poljubnoSt < 1);

    cout << "seštevek vseh stevk je: \t" << sumOfAllNumbers(poljubnoSt) << "\n";

    isPerfect(sumOfAllNumbers(poljubnoSt));

    return 0;
}
