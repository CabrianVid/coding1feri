//
// Created by LENOVO on 5. 04. 2022.
//

#ifndef VAJA0601A_COLORCODE_H
#define VAJA0601A_COLORCODE_H



enum class ColorCode{
    red=31, green=32, blue=34, Default = 49
};



#endif //VAJA0601A_COLORCODE_H
