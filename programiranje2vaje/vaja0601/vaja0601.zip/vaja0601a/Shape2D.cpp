//
// Created by LENOVO on 5. 04. 2022.
//


#include "Shape2D.h"

Shape2D::Shape2D(ColorCode color) {
    this->color=color;
}

Shape2D::Shape2D() {}



void Shape2D::draw() {

}