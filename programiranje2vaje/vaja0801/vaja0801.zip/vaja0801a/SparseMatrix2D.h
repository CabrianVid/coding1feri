//
// Created by LENOVO on 2. 05. 2022.
//

#ifndef VAJA0801A_SPARSEMATRIX2D_H
#define VAJA0801A_SPARSEMATRIX2D_H


#include<vector>
#include"Element.h"


template<typename T>
class SparseMatrix2D{
private:
    std::vector<Element<T>> elements;
    unsigned int sizeX;
    unsigned int sizeY;
    T defaultElement;
public:
    SparseMatrix2D(unsigned int sizeX, unsigned int sizeY, T defaultElement);
    void set(unsigned int x, unsigned int y, T value);
    Element<T> at(unsigned int x, unsigned int y);
    unsigned int getSizeX();
    unsigned int getSizeY();


};

template<typename T>
SparseMatrix2D<T>::SparseMatrix2D(unsigned int sizeX, unsigned int sizeY, T defaultElement) :
        sizeX(sizeX), sizeY(sizeY), defaultElement(defaultElement) {}


template<typename T>
void SparseMatrix2D<T>::set(unsigned int x, unsigned int y, T value) {
    for(int i=0; i<elements.size(); i++){
        if(elements[i].getX()==x && elements[i].getY()==y){
            elements[i].setValue(value);
            return;
        }
    }
    elements.push_back(Element<T>(x,y,value));
}

template<typename T>
Element<T> SparseMatrix2D<T>::at(unsigned int x, unsigned int y) {
    for(int i=0;i<elements.size(); i++){
        if(elements[i].getX()==x && elements[i].getY()==y){
            return elements[i];
        }
    }
    return Element<T>(x,y,defaultElement);
}

template<typename T>
unsigned int SparseMatrix2D<T>::getSizeX() {
    return sizeX;
}

template<typename T>
unsigned int SparseMatrix2D<T>::getSizeY() {
    return sizeY;
}



#endif //VAJA0801A_SPARSEMATRIX2D_H
